<?php
define('DT_VERSION', '7.0');
define('DT_RELEASE', '20190122');
?>