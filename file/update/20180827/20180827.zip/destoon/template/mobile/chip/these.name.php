<?php
$names = array (
  'album' => '产品图册',
  'captcha' => '验证码',
  'comment' => '评论调用',
  'contact' => '联系方式收费',
  'content' => '内容收费',
  'empty' => '列表为空',
  'goods' => '订单商品',
  'guest_contact' => '游客联系方式',
  'password' => '密码输入',
  'poll' => '行业票选',
  'property_js' => '分类属性JS',
  'question' => '验证问题',
);
?>